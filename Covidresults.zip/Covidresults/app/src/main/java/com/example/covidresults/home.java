package com.example.covidresults;
import androidx.appcompat.app.AppCompatActivity;
        import android.os.Bundle;
        import android.content.Intent;
        import android.content.pm.ActivityInfo;
        import android.view.View;
        import android.widget.Button;


public class home extends AppCompatActivity {
    Button startbutton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().hide();
        setContentView(R.layout.activity_home);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //for Start Button
        startbutton=findViewById(R.id.startButton);

        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(home.this,list.class);
                startActivity(in);
                finish();


            }
        });

    }
}