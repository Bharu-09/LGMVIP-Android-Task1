package com.example.covidresults;
public class StateModel {
    private String states;

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public StateModel(String states) {
        this.states = states;
    }
}
